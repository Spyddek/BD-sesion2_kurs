from django.urls import path
from . import views

urlpatterns = [
    path('services/', views.services_list, name='services_list'),
    path('free-slots/', views.free_slots, name='free_slots'),
    path('book/', views.book_appointment, name='book_appointment'),
    path('cancel/', views.cancel_appointment, name='cancel_appointment'),
    path('review/', views.add_review, name='add_review'),
]
