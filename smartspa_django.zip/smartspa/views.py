import json
from datetime import datetime
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.db import connection
from django.utils.dateparse import parse_date

from .models import Service, ScheduleSlot

def ok(data=None):
    return JsonResponse({'ok': True, 'data': data})

def err(message, code=400):
    return JsonResponse({'ok': False, 'error': message}, status=code)

def services_list(request):
    qs = Service.objects.all().order_by('name').values('id','name','description','base_price','duration_min')
    return ok(list(qs))

def free_slots(request):
    city = request.GET.get('city')
    service = request.GET.get('service')
    dt_str = request.GET.get('date')
    if not (city and service and dt_str):
        return err('Укажите параметры: city, service, date (YYYY-MM-DD).')
    try:
        dt = parse_date(dt_str)
        if not dt:
            raise ValueError
    except Exception:
        return err('Некорректная дата. Ожидается формат YYYY-MM-DD.')

    # ORM-соединения по связям и фильтр по дате
    qs = (ScheduleSlot.objects
          .filter(is_booked=False,
                  start_ts__date=dt,
                  master__salon__city=city,
                  master__salon__salonservice__service__name=service)
          .select_related('master','master__salon')
          .order_by('start_ts')
          .values('id','start_ts','end_ts','master__full_name','master__salon__name'))
    # Переименуем ключи для удобства
    data = [{
        'id': r['id'],
        'start_ts': r['start_ts'],
        'end_ts': r['end_ts'],
        'master': r['master__full_name'],
        'salon': r['master__salon__name'],
    } for r in qs[:200]]
    return ok(data)

@csrf_exempt
def book_appointment(request):
    if request.method != 'POST':
        return err('Только POST.')
    try:
        payload = json.loads(request.body.decode('utf-8'))
        params = (
            int(payload['client_id']),
            int(payload['salon_id']),
            int(payload['master_id']),
            int(payload['service_id']),
            int(payload['slot_id']),
        )
    except Exception:
        return err('Ожидаются поля: client_id, salon_id, master_id, service_id, slot_id (числа).')

    with connection.cursor() as cur:
        cur.execute('SELECT smart_spa."забронировать_приём"(%s,%s,%s,%s,%s);', params)
        row = cur.fetchone()
    return ok({'appointment_id': row[0] if row else None})

@csrf_exempt
def cancel_appointment(request):
    if request.method != 'POST':
        return err('Только POST.')
    try:
        payload = json.loads(request.body.decode('utf-8'))
        appointment_id = int(payload['appointment_id'])
    except Exception:
        return err('Ожидается поле: appointment_id (число).')

    with connection.cursor() as cur:
        cur.execute('SELECT smart_spa."отменить_запись"(%s);', [appointment_id])
    return ok({'cancelled': True})

@csrf_exempt
def add_review(request):
    if request.method != 'POST':
        return err('Только POST.')
    try:
        payload = json.loads(request.body.decode('utf-8'))
        salon_id = int(payload['salon_id'])
        client_id = int(payload['client_id'])
        appointment_id = int(payload['appointment_id'])
        rating = int(payload['rating'])
        comment = payload.get('comment','')
    except Exception:
        return err('Ожидаются: salon_id, client_id, appointment_id, rating, comment?')

    with connection.cursor() as cur:
        cur.execute(
            'INSERT INTO smart_spa.reviews(salon_id, client_id, appointment_id, rating, comment) VALUES (%s,%s,%s,%s,%s) RETURNING id;',
            [salon_id, client_id, appointment_id, rating, comment]
        )
        rid = cur.fetchone()[0]
    return ok({'review_id': rid})
