from django.db import models

# ВАЖНО: существующая БД в схеме smart_spa, поэтому ставим managed=False и задаём schema-qualified db_table.

class Role(models.Model):
    id = models.AutoField(primary_key=True)
    code = models.CharField(max_length=32, unique=True)
    name = models.CharField(max_length=128)

    class Meta:
        managed = False
        db_table = 'smart_spa"."roles'

    def __str__(self):
        return f'{self.code} ({self.name})'


class Salon(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=200)
    city = models.CharField(max_length=120)
    address = models.CharField(max_length=300)
    phone = models.CharField(max_length=32, null=True, blank=True)
    created_at = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."salons'

    def __str__(self):
        return f'{self.name} ({self.city})'


class Service(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    base_price = models.DecimalField(max_digits=10, decimal_places=2)
    duration_min = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."services'

    def __str__(self):
        return self.name


class AppUser(models.Model):
    id = models.BigAutoField(primary_key=True)
    full_name = models.CharField(max_length=200)
    phone = models.CharField(max_length=32, unique=True)
    email = models.CharField(max_length=200, null=True, blank=True)
    password_hash = models.TextField()
    role = models.ForeignKey(Role, models.DO_NOTHING, db_column='role_id')
    created_at = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."users'

    def __str__(self):
        return self.full_name


class Master(models.Model):
    id = models.BigAutoField(primary_key=True)
    salon = models.ForeignKey(Salon, models.DO_NOTHING, db_column='salon_id')
    full_name = models.CharField(max_length=200)
    specialization = models.CharField(max_length=200, null=True, blank=True)
    active = models.BooleanField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."masters'

    def __str__(self):
        return self.full_name


class SalonService(models.Model):
    salon = models.ForeignKey(Salon, models.DO_NOTHING, db_column='salon_id')
    service = models.ForeignKey(Service, models.DO_NOTHING, db_column='service_id')
    price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    class Meta:
        managed = False
        db_table = 'smart_spa"."salon_services'
        unique_together = (('salon', 'service'),)


class ScheduleSlot(models.Model):
    id = models.BigAutoField(primary_key=True)
    master = models.ForeignKey(Master, models.DO_NOTHING, db_column='master_id')
    start_ts = models.DateTimeField()
    end_ts = models.DateTimeField()
    is_booked = models.BooleanField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."schedule_slots'


class Appointment(models.Model):
    STATUS_CHOICES = (
        ('ожидает подтверждения', 'ожидает подтверждения'),
        ('подтверждена', 'подтверждена'),
        ('отменена', 'отменена'),
        ('завершена', 'завершена'),
    )
    id = models.BigAutoField(primary_key=True)
    client = models.ForeignKey(AppUser, models.DO_NOTHING, db_column='client_id', related_name='appointments')
    salon = models.ForeignKey(Salon, models.DO_NOTHING, db_column='salon_id')
    master = models.ForeignKey(Master, models.DO_NOTHING, db_column='master_id')
    service = models.ForeignKey(Service, models.DO_NOTHING, db_column='service_id')
    slot = models.ForeignKey(ScheduleSlot, models.DO_NOTHING, db_column='slot_id')
    status = models.CharField(max_length=30, choices=STATUS_CHOICES)
    created_at = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."appointments'


class Review(models.Model):
    id = models.BigAutoField(primary_key=True)
    salon = models.ForeignKey(Salon, models.DO_NOTHING, db_column='salon_id')
    client = models.ForeignKey(AppUser, models.SET_NULL, db_column='client_id', null=True, blank=True)
    appointment = models.OneToOneField(Appointment, models.SET_NULL, db_column='appointment_id', null=True, blank=True)
    rating = models.SmallIntegerField()
    comment = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'smart_spa"."reviews'
