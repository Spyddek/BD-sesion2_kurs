from django.contrib import admin
from . import models

# Регистрируем основные модели в админке для быстрого просмотра/редактирования
@admin.register(models.Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ('id', 'code', 'name')
    search_fields = ('code', 'name')

@admin.register(models.AppUser)
class AppUserAdmin(admin.ModelAdmin):
    list_display = ('id', 'full_name', 'phone', 'email', 'role', 'created_at')
    search_fields = ('full_name', 'phone', 'email')
    list_filter = ('role',)

@admin.register(models.Salon)
class SalonAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'city', 'address', 'phone', 'created_at')
    search_fields = ('name', 'city', 'address')

@admin.register(models.Master)
class MasterAdmin(admin.ModelAdmin):
    list_display = ('id', 'full_name', 'salon', 'specialization', 'active')
    list_filter = ('active', 'salon')
    search_fields = ('full_name', 'specialization')

@admin.register(models.Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'base_price', 'duration_min')
    search_fields = ('name',)

@admin.register(models.SalonService)
class SalonServiceAdmin(admin.ModelAdmin):
    list_display = ('salon', 'service', 'price')
    list_filter = ('salon', 'service')

@admin.register(models.ScheduleSlot)
class ScheduleSlotAdmin(admin.ModelAdmin):
    list_display = ('id', 'master', 'start_ts', 'end_ts', 'is_booked')
    list_filter = ('master', 'is_booked')
    date_hierarchy = 'start_ts'

@admin.register(models.Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'client', 'salon', 'master', 'service', 'slot', 'status', 'created_at')
    list_filter = ('status', 'salon', 'master', 'service')

@admin.register(models.Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('id', 'salon', 'client', 'appointment', 'rating', 'created_at')
    list_filter = ('rating', 'salon')
