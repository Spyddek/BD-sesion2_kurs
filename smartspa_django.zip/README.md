# SMART-SPA Django (demo API)

Минимальный Django-проект для работы с существующей БД PostgreSQL (схема `smart_spa`, БД `kurs`, порт `5433`).

## Установка
```bash
cd smartspa_django
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Настройка подключения к БД
По умолчанию проект ожидает PostgreSQL:
- HOST: 127.0.0.1
- PORT: 5433
- NAME: kurs
- USER: postgres
- PASSWORD: (задай через переменную окружения PGPASSWORD или впиши в settings.py — только для локальной разработки)

Можно задать через переменные окружения:
```
set PGHOST=127.0.0.1
set PGPORT=5433
set PGDATABASE=kurs
set PGUSER=postgres
set PGPASSWORD=your_password
```

## Миграции
Модели этого приложения помечены `managed=False` и указывают на уже существующие таблицы.  
Запусти базовые миграции Django для админки/аутентификации:
```bash
python manage.py migrate
python manage.py createsuperuser  # по желанию для админки
```

## Запуск
```bash
python manage.py runserver 8000
```

## Эндпоинты (JSON)
- `GET /api/services/` — список услуг.
- `GET /api/free-slots/?city=Москва&service=Классический массаж&date=2025-11-03` — свободные слоты.
- `POST /api/book/` — бронирование (тело JSON: client_id, salon_id, master_id, service_id, slot_id). Вызывает функцию `smart_spa."забронировать_приём"`.
- `POST /api/cancel/` — отмена (JSON: appointment_id). Вызывает `smart_spa."отменить_запись"`.
- `POST /api/review/` — отзыв (JSON: salon_id, client_id, appointment_id, rating, comment). Триггер в БД проверит «только после завершения визита».

## Админка
`/admin/` — можно просматривать/редактировать записи напрямую.
