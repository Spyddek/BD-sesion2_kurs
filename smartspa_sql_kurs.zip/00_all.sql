\set ON_ERROR_STOP on
\i 01_schema.sql
\i 02_tables.sql
\i 03_functions.sql
\i 05_seed.sql
-- \i 04_reports.sql  -- отчёты можно выполнять по желанию
