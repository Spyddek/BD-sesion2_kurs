SET search_path TO smart_spa, public;
SET client_min_messages TO notice;

-- Бронирование
SELECT забронировать_приём(
  (SELECT id FROM users   WHERE full_name='Иван Петров'),
  (SELECT id FROM salons  WHERE name='SPA «Лотос»'),
  (SELECT id FROM masters WHERE full_name='Мария Смирнова'),
  (SELECT id FROM services WHERE name='Классический массаж'),
  (SELECT id FROM schedule_slots WHERE is_booked = FALSE ORDER BY start_ts LIMIT 1)
) AS app1;

-- Повторное бронирование (ошибка)
SELECT забронировать_приём(
  (SELECT id FROM users   WHERE full_name='Иван Петров'),
  (SELECT id FROM salons  WHERE name='SPA «Лотос»'),
  (SELECT id FROM masters WHERE full_name='Мария Смирнова'),
  (SELECT id FROM services WHERE name='Классический массаж'),
  (SELECT id FROM schedule_slots ORDER BY start_ts LIMIT 1)
);

-- Отмена
SELECT отменить_запись((SELECT id FROM appointments ORDER BY id DESC LIMIT 1));
