-- Запрет пересечения слотов одного мастера
CREATE OR REPLACE FUNCTION запретить_пересечение_слотов()
RETURNS trigger AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM schedule_slots s
    WHERE s.master_id = NEW.master_id
      AND tstzrange(s.start_ts, s.end_ts, '[)') && tstzrange(NEW.start_ts, NEW.end_ts, '[)')
      AND s.id <> COALESCE(NEW.id, -1)
  ) THEN
    RAISE EXCEPTION 'Ошибка: данный слот пересекается с уже существующим временем работы мастера %', NEW.master_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_проверка_слотов ON schedule_slots;
CREATE TRIGGER trg_проверка_слотов
BEFORE INSERT OR UPDATE ON schedule_slots
FOR EACH ROW EXECUTE FUNCTION запретить_пересечение_слотов();

-- Бронирование
CREATE OR REPLACE FUNCTION забронировать_приём(
  p_клиент BIGINT, p_салон BIGINT, p_мастер BIGINT, p_услуга BIGINT, p_слот BIGINT
) RETURNS BIGINT AS $$
DECLARE v_id BIGINT;
BEGIN
  PERFORM 1 FROM schedule_slots WHERE id = p_слот AND master_id = p_мастер FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ошибка: указанный слот не найден или не принадлежит выбранному мастеру.';
  END IF;

  IF EXISTS (SELECT 1 FROM schedule_slots WHERE id = p_слот AND is_booked) THEN
    RAISE EXCEPTION 'Ошибка: выбранный слот уже занят другим клиентом.';
  END IF;

  UPDATE schedule_slots SET is_booked = TRUE WHERE id = p_слот;

  INSERT INTO appointments(client_id, salon_id, master_id, service_id, slot_id, status)
  VALUES (p_клиент, p_салон, p_мастер, p_услуга, p_слот, 'подтверждена')
  RETURNING id INTO v_id;

  RAISE NOTICE 'Запись успешно создана. Номер записи: %', v_id;
  RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- Отмена
CREATE OR REPLACE FUNCTION отменить_запись(p_id_записи BIGINT) 
RETURNS void AS $$
DECLARE v_слот BIGINT;
BEGIN
  UPDATE appointments
     SET status = 'отменена'
   WHERE id = p_id_записи AND status IN ('ожидает подтверждения','подтверждена')
  RETURNING slot_id INTO v_слот;

  IF FOUND THEN
    UPDATE schedule_slots SET is_booked = FALSE WHERE id = v_слот;
    RAISE NOTICE 'Запись успешно отменена и слот освобождён.';
  ELSE
    RAISE NOTICE 'Отмена невозможна: запись не найдена или уже отменена/завершена.';
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Отзыв только после завершённого визита
CREATE OR REPLACE FUNCTION проверить_отзыв_после_визита()
RETURNS trigger AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM appointments a
    WHERE a.id = NEW.appointment_id
      AND a.client_id = NEW.client_id
      AND a.salon_id  = NEW.salon_id
      AND a.status    = 'завершена'
  ) THEN
    RAISE EXCEPTION 'Ошибка: отзыв можно оставить только после завершённого визита клиента.';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_проверка_отзыва ON reviews;
CREATE TRIGGER trg_проверка_отзыва
BEFORE INSERT OR UPDATE ON reviews
FOR EACH ROW EXECUTE FUNCTION проверить_отзыв_после_визита();
