-- Популярность процедур (топ-10)
SELECT s.name AS service_name, COUNT(a.id) AS visits
FROM appointments a
JOIN services s ON s.id = a.service_id
WHERE a.status = 'завершена'
GROUP BY s.name
ORDER BY visits DESC
LIMIT 10;

-- Свободные слоты по услуге и городу на дату ($1=город, $2=услуга, $3=дата)
SELECT sl.id, sl.start_ts, sl.end_ts, m.full_name AS master, sa.name AS salon
FROM schedule_slots sl
JOIN masters m ON m.id = sl.master_id
JOIN salons sa ON sa.id = m.salon_id
JOIN salon_services ss ON ss.salon_id = sa.id
JOIN services s ON s.id = ss.service_id
WHERE sl.is_booked = FALSE
  AND sa.city = $1
  AND s.name = $2
  AND sl.start_ts::date = $3
ORDER BY sl.start_ts;

-- Загрузка мастеров за период ($1=дата от, $2=дата до)
SELECT m.full_name, COUNT(a.id) AS completed_count
FROM appointments a
JOIN masters m ON m.id = a.master_id
WHERE a.status = 'завершена'
  AND a.created_at >= $1 AND a.created_at < $2
GROUP BY m.full_name
ORDER BY completed_count DESC;
