SET search_path TO smart_spa, public;

-- Роли
INSERT INTO roles(code, name) VALUES
  ('client','Клиент'), ('salon','Салон'), ('admin','Администратор')
ON CONFLICT DO NOTHING;

-- Клиент
INSERT INTO users(full_name, phone, email, password_hash, role_id)
VALUES ('Иван Петров', '+79990000001', 'ivan@example.com', 'hash',
        (SELECT id FROM roles WHERE code='client'))
ON CONFLICT DO NOTHING;

-- Салон
INSERT INTO salons(name, city, address, phone)
VALUES ('SPA «Лотос»','Москва','ул. Примерная, 1','+7 (499) 000-00-00')
ON CONFLICT DO NOTHING;

-- Мастер
INSERT INTO masters(salon_id, full_name, specialization)
VALUES (
  (SELECT id FROM salons WHERE name='SPA «Лотос»'),
  'Мария Смирнова','Массаж'
)
ON CONFLICT DO NOTHING;

-- Услуга
INSERT INTO services(name, description, base_price, duration_min)
VALUES ('Классический массаж','Расслабляющий массаж', 2500, 60)
ON CONFLICT DO NOTHING;

-- Цена услуги в салоне
INSERT INTO salon_services(salon_id, service_id, price)
VALUES (
  (SELECT id FROM salons WHERE name='SPA «Лотос»'),
  (SELECT id FROM services WHERE name='Классический массаж'),
  3000
)
ON CONFLICT DO NOTHING;

-- Сетка слотов на 5 дней, шаг 60 минут, 10:00–18:00 (локальная TZ)
WITH params AS (
  SELECT 
    (SELECT id FROM masters WHERE full_name='Мария Смирнова') AS master_id,
    (now()::date + 1) AS start_day,
    5 AS days,
    60 AS step_min
)
INSERT INTO schedule_slots(master_id, start_ts, end_ts)
SELECT p.master_id,
       ((p.start_day + d.dn) + t.ti)::timestamptz AS start_ts,
       ((p.start_day + d.dn) + t.ti + (p.step_min||' min')::interval)::timestamptz AS end_ts
FROM params p,
     generate_series(0, p.days-1) AS d(dn),
     generate_series(TIME '10:00', TIME '17:00', (p.step_min||' min')::interval) AS t(ti);
