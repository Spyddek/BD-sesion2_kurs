SET client_encoding TO 'UTF8';
SET datestyle TO 'ISO, DMY';

CREATE SCHEMA IF NOT EXISTS smart_spa;
SET search_path TO smart_spa, public;
