-- Роли и пользователи
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    code VARCHAR(32) UNIQUE NOT NULL, -- 'client', 'salon', 'admin'
    name VARCHAR(128) NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    full_name VARCHAR(200) NOT NULL,
    phone VARCHAR(32) UNIQUE NOT NULL,
    email VARCHAR(200) UNIQUE,
    password_hash TEXT NOT NULL,
    role_id INTEGER NOT NULL REFERENCES roles(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Салоны и мастера
CREATE TABLE IF NOT EXISTS salons (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    city VARCHAR(120) NOT NULL,
    address VARCHAR(300) NOT NULL,
    phone VARCHAR(32),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS masters (
    id BIGSERIAL PRIMARY KEY,
    salon_id BIGINT NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
    full_name VARCHAR(200) NOT NULL,
    specialization VARCHAR(200),
    active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Услуги и цены в салонах
CREATE TABLE IF NOT EXISTS services (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    base_price NUMERIC(10,2) NOT NULL CHECK (base_price >= 0),
    duration_min INTEGER NOT NULL CHECK (duration_min BETWEEN 15 AND 480)
);

CREATE TABLE IF NOT EXISTS salon_services (
    salon_id BIGINT NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
    service_id BIGINT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    price NUMERIC(10,2) CHECK (price >= 0),
    PRIMARY KEY (salon_id, service_id)
);

-- Расписания и записи
CREATE TABLE IF NOT EXISTS schedule_slots (
    id BIGSERIAL PRIMARY KEY,
    master_id BIGINT NOT NULL REFERENCES masters(id) ON DELETE CASCADE,
    start_ts TIMESTAMPTZ NOT NULL,
    end_ts   TIMESTAMPTZ NOT NULL,
    is_booked BOOLEAN NOT NULL DEFAULT FALSE,
    CHECK (end_ts > start_ts)
);

CREATE INDEX IF NOT EXISTS idx_schedule_master_start ON schedule_slots(master_id, start_ts);

CREATE TABLE IF NOT EXISTS appointments (
    id BIGSERIAL PRIMARY KEY,
    client_id BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    salon_id  BIGINT NOT NULL REFERENCES salons(id) ON DELETE RESTRICT,
    master_id BIGINT NOT NULL REFERENCES masters(id) ON DELETE RESTRICT,
    service_id BIGINT NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
    slot_id BIGINT NOT NULL UNIQUE REFERENCES schedule_slots(id) ON DELETE RESTRICT,
    status VARCHAR(30) NOT NULL CHECK (status IN ('ожидает подтверждения','подтверждена','отменена','завершена')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Отзывы
CREATE TABLE IF NOT EXISTS reviews (
    id BIGSERIAL PRIMARY KEY,
    salon_id BIGINT NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
    client_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
    appointment_id BIGINT UNIQUE REFERENCES appointments(id) ON DELETE SET NULL,
    rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviews_salon_created ON reviews (salon_id, created_at DESC);
